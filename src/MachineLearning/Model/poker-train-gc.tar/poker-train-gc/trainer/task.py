from trainer.CoachMLP import train
if __name__ == "__main__":
    train()
